//Name: Brendan Best
public class Ex1_6 {

	public static void main(String[] args) {
			int num = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10;
			System.out.println("The total of 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10 is " + num);

	}

}
