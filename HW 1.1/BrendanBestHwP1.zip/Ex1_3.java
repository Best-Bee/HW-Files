//Name: Brendan Best
public class Ex1_3 {
	public static void main(String[] args) {
		System.out.println("  JJJJJ   aaaa    v     v   aaaa         ");
		System.out.println("    J    a    a    v   v   a    a        ");
		System.out.println("    J    a    a     v v    a    a        ");
		System.out.println("  JJ      aaa  a     v      aaa  a       ");
	}
}